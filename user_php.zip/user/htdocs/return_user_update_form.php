<?php

require('../connect/db_incl.php'); //connect to the database

if((isset($_GET["pk_user_id"]) && is_numeric(htmlspecialchars($_GET["pk_user_id"])))){

    $sql = "SELECT pk_user_id, user_first_name, user_last_name, user_login, user_email, user_password
	FROM `user` WHERE `pk_user_id` = '" . $_GET["pk_user_id"] . "' LIMIT 0, 30 ";

    $results = mysqli_query($dbc,$sql);

    $row = mysqli_fetch_array($results);

    ?>
    <form action="update_user.php" class="form-horizontal" method="POST">

        First Name <input type="text" name="fname" value="<?php echo $row["user_first_name"] ?>" ><br>
        Last Name  <input type="text" name="lname" value="<?php echo $row["user_last_name"] ?>"/><br>
        Login      <input type="text" name="login" value="<?php echo $row["user_login"] ?>"/><br>
        Email      <input type="text" name="email" value="<?php echo $row["user_email"] ?>"/><br>

        <input type="hidden" name="id" value="<?php echo $row["pk_user_id"] ?>"/>

        <button type="submit" >Update!</button>

    </form>
<?php
}
?>