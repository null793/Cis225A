<link href="/bootstrap/dist/css/bootstrap.css" rel="stylesheet">
<script src="/bootstrap/assets/js/jquery.js"></script>
<script src="/bootstrap/dist/js/bootstrap.js"></script>

<?php
//this page creates login page and reports any errors

//print any errors
if(isset($errors) && !empty($errors)){
    echo '<h1>Error!</h1>
    <p class="error">The following error(s) occurred:<br/>';
    foreach($errors as $msg){
        echo " - $msg<br/>\n";
    }
    echo '</p><p>Please try again.</p>';
}

//display the form
?>
<style>
    body{
        padding-top: 50px;
    }
    #password_holder{
        width: 300px;
        padding:10px;
        border:1px solid #404040;
        border-radius: 5px;
        display: block;
        background-color: #CCC;

    }
    .center
    {
        margin-left:auto;
        margin-right:auto;
        width:70%;
        background-color:#b0e0e6;
    }
</style>
<head>
    <title>Login</title>
</head>

<h1>Login</h1>
<form action="../user_login.php" method="post">
    <p>Email Address: <input type="text" name="email" size="20" maxlength="60" /></p>
    <p>Password: <input type="text" name="pass" type="password" size="20" maxlength="20"/></p>
    <p><input type="submit" name="submit" value="Login"/></p>
</form>