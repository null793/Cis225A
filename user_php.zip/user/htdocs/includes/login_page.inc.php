<?php #script 12.1 login page
//this page creates login page and reports any errors

//include the header
$page_title = 'Login';
include('includes/header.html');

//print any errors
if(isset($errors) && !empty($errors)){
    echo '<h1>Error!</h1>
    <p class="error">The following error(s) occurred:<br/>';
    foreach($errors as $msg){
        echo " - $msg<br/>\n";
    }
    echo '</p><p>Please try again.</p>';
}

//display the form
?>
<h1>Login</h1>
<form action="../login.php" method="post">
    <p>Email Address: <input type="text" name="email" size="20" maxlength="60" /></p>
    <p>Password: <input type="text" name="pass" type="password" size="20" maxlength="20"/></p>
    <p><input type="submit" name="submit" value="Login"/></p>
</form>

<?php include('includes/footer.html');
?>